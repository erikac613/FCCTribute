A Pen created at CodePen.io. You can find this one at https://codepen.io/erikac613/pen/MpxoxQ.

 This is my tribute page for the first FreeCodeCamp Basic Front End Dev challenge. I chose the Maya scholar Linda Schele as my subject.